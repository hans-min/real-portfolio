var s;const e=((s=globalThis.__sveltekit_xl6593)==null?void 0:s.base)??"/real-portfolio";var a;const l=((a=globalThis.__sveltekit_xl6593)==null?void 0:a.assets)??e;export{l as a,e as b};
