var s;const e=((s=globalThis.__sveltekit_r296gp)==null?void 0:s.base)??"/real-portfolio";var a;const t=((a=globalThis.__sveltekit_r296gp)==null?void 0:a.assets)??e;export{t as a,e as b};
