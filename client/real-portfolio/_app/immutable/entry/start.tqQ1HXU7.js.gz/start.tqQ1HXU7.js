import{a as t}from"../chunks/entry.salKkXrQ.js";export{t as start};
