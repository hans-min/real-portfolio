import{a as t}from"../chunks/entry.Dcw3SerC.js";export{t as start};
